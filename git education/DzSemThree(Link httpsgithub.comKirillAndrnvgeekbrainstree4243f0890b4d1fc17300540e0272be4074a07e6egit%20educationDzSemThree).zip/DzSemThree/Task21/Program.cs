﻿// Напишите программу, которая принимает на вход координаты двух точек и находит расстояние между ними в 3D пространстве.

Console.Write ("Enter x1:");
int x1 = int.Parse(Console.ReadLine());

Console.Write ("Enter y1:");
int y1 = int.Parse(Console.ReadLine());

Console.Write ("Enter z1:");
int z1 = int.Parse(Console.ReadLine());

Console.Write ("Enter x2:");
int x2 = int.Parse(Console.ReadLine());

Console.Write ("Enter y2:");
int y2 = int.Parse(Console.ReadLine());

Console.Write ("Enter z2:");
int z2 = int.Parse(Console.ReadLine());

double s = Math.Sqrt((Math.Pow(x1 - y1,2) + Math.Pow(x2 - y2,2) + Math.Pow(z1 - z2,2)));

Console.WriteLine($"distance {s}");
